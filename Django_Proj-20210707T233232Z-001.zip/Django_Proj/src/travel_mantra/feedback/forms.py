from .models import Feedback
from django import forms

class RawFeedbackForm(forms.Form):
	name=forms.CharField(
			label="Name ",
			widget=forms.TextInput(
				attrs={
					"placeholder":"Your Name Here Please"
				}
			)
		)
	review=forms.CharField(
			label="Feedback ",
			widget=forms.Textarea(
				attrs={
					"placeholder":"Please tell us what you feel about our website",
					'rows':10,
					'cols':50
				}
			)
		)
	suggestions=forms.CharField(
			label="Suggestions",
			widget=forms.Textarea(
				attrs={
					"placeholder":"Any improvements or suggestions, you would like us to make.",
					'rows':10,
					'cols':30
				}
			)
		)
	ratings=forms.DecimalField(
			label="Ratings",
			widget=forms.TextInput(
				attrs={
					"placeholder":"In between 1-5"
				}

			)
		)