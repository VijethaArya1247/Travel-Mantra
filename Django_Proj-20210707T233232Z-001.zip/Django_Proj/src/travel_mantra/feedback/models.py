from django.db import models

# Create your models here.
class Feedback(models.Model):
	name=models.CharField(max_length=120)
	review=models.TextField(blank=False)
	suggestions=models.TextField(blank=True)
	ratings=models.DecimalField(decimal_places=0, max_digits=1)