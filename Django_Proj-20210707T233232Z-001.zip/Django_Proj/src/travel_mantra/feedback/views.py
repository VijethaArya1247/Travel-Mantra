from django.shortcuts import render

# Create your views here.

from .models import Feedback
from .forms import RawFeedbackForm
# Create your views here.

def feedback_create_view(request):
	my_form=RawFeedbackForm()
	if request.method=='POST':		
		my_form=RawFeedbackForm(request.POST)
		if my_form.is_valid():
			#now the data is good
			print(my_form.cleaned_data)
			Feedback.objects.create(**my_form.cleaned_data)
			my_form=RawFeedbackForm()
	context={
		"form":my_form
	}
	return render(request,"feedback_form.html",context)
