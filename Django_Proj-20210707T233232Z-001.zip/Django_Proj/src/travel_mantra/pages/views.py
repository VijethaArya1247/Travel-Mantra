from django.shortcuts import render
from django.http import HttpResponse

from django.views.generic import CreateView

#from feedback.forms import RawFeedbackForm
#from feedback.models import Feedback

# Create your views here.

def home_view(request,*args,**kwargs):
	return render(request,"index.html",{})

def new_view(request,*args,**kwargs):
	return render(request,"new.html",{})

def book_view(request,*args,**kwargs):
	return render(request,"book.html",{})

def extra_services(request,*args,**kwargs):
	return render(request,"extra.html",{})

def book_contact(request,*args,**kwargs):
	return render(request,"contact.html",{})

# def feedback_form(request,*args,**kwargs):
#  	return render(request,"feedback_form.html",{})

# def feedback_create_view(request):
# 	my_form=RawFeedbackForm()
# 	if request.method=='POST':		
# 		my_form=RawFeedbackForm(request.POST)
# 		if my_form.is_valid():
# 			#now the data is good
# 			print(my_form.cleaned_data)
# 			Feedback.objects.create(**my_form.cleaned_data)
# 			#my_form=RawFeedbackForm()
# 	context={
# 		"form":my_form
# 	}
# 	return render(request,"feedback_form.html",context)
